# Changelog

All notable changes follow Semantic Versioning. During `0.x`, a breaking public API or inferred-type change is called out in the minor release notes. Consumers must pin exact versions.

## 0.1.1 - 2026-08-12

### Changed

- Re-established a reproducible reviewed tarball and isolated packed-consumer verification without changing the public API.

## 0.1.0 - 2026-08-11

### Added

- Explicit server/client schema definition with inferred output types.
- String, URL, enum, integer, boolean, secret, and public-credential fields.
- Throwing `parse()` and non-throwing `safeParse()`.
- Missing, invalid, exposure-violation, and unknown-client-key issues.
- Fail-closed production secret and production-only required policies.
- Redacted diagnostics with a 50-issue ceiling.
- Pure Next, Vite, and Worker input adapters.
- Next, Vite, and Worker compile fixtures plus negative security tests.
