# `@youngbin-studio/env`

Zero-runtime-dependency environment validation for explicit server/client boundaries. It validates startup configuration without reading files, globals, networks, Secret managers, or telemetry.

## Public API

```ts
import { defineEnv, fields } from "@youngbin-studio/env";
import { nextEnv } from "@youngbin-studio/env/adapters/next";

export const env = defineEnv({
  app: "invitation-platform",
  environment: process.env.NODE_ENV ?? "development",
  server: {
    SUPABASE_SERVICE_ROLE_KEY: fields.secret({ requiredInProduction: true }),
    ADMIN_EMAILS: fields.string({ optional: true }),
  },
  client: {
    NEXT_PUBLIC_SUPABASE_URL: fields.url({ protocols: ["https:"] }),
    NEXT_PUBLIC_SUPABASE_ANON_KEY: fields.publicCredential(),
  },
}).parse(
  nextEnv({
    server: process.env,
    client: {
      NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
      NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    },
  }),
);
```

`parse()` throws `EnvValidationError`. `safeParse()` returns a discriminated union:

```ts
const result = definition.safeParse(input);
if (!result.success) {
  // Log issues only in a trusted build/startup surface.
  // Show clients a generic startup error.
  console.error(result.issues);
}
```

Supported fields:

- `fields.string()`
- `fields.url()`
- `fields.enum(["a", "b"] as const)`
- `fields.integer()`
- `fields.boolean()`
- `fields.secret()`
- `fields.publicCredential()`

Common options are `optional`, `requiredInProduction`, and `default`. Production secret defaults are always rejected. String-like fields support minimum length; strings also support maximum length, URLs can restrict protocols, and integers can restrict minimum/maximum values.

## Exposure policy

- A `secret` field is never valid in the client schema.
- A client key matching `SECRET`, `SERVICE_ROLE`, `PRIVATE_KEY`, `PASSWORD`, or `TOKEN` is rejected.
- A credential known to be public may use `fields.publicCredential({ allowSensitiveName: true })`, but that exception must be reviewed. Public does not mean authorized; Supabase anon keys still require correct RLS.
- Unknown client keys fail validation. Unrelated server/OS/CI keys are ignored and never returned.
- Diagnostics contain only app/environment in the top-level error and key/scope/code/generic message in issues. They do not compute or expose configuration values, prefixes, lengths, hashes, or derived identifiers.
- At most 50 issues are returned.

## Adapters

- `nextEnv({ server, client })`: preserves a full server source and an explicitly picked client object.
- `viteEnv(client)`: accepts an explicitly picked Vite client object without reading `import.meta.env` itself.
- `workerEnv(bindings, client?)`: treats Worker bindings as server input and accepts an optional explicit client object.

Adapters are pure functions. They do not read globals, so tests and non-standard runtimes can provide ordinary objects.

## Threat boundary

This package reduces accidental configuration exposure and catches startup misconfiguration. It does not protect against a compromised build process, malicious dependency, provider-side leak, runtime authorization failure, wrong RLS policy, cross-app JWT acceptance, or a Secret already exposed elsewhere.

## Migration

1. Pin the exact package version and commit the consumer lockfile.
2. Model only a small existing environment subset first; do not rename keys or change providers in the same change.
3. Replace direct reads with the parsed result at one boundary.
4. Run product build, startup smoke, authorization/RLS negative tests, and artifact inspection.
5. Observe two release cycles before expanding adoption.

The first intended pilot is a local/low-risk app with few or no required variables. A second consumer should validate an existing fail-closed configuration subset before higher-risk apps adopt the package.

## Rollback

Pin the prior exact package version or restore the repository-local environment validator. Package rollback is code-only: it must not mutate schemas, provider projects, credentials, or environment key names. Target rollback time is under 30 minutes.

## Module support

v0.1 publishes ESM and TypeScript declarations for Node.js 22.14 or newer. Next, Vite, and Worker fixtures compile in the package typecheck. CommonJS is not published in v0.1.
